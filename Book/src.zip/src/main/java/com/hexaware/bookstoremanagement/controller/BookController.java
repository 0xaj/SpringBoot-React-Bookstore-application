package com.hexaware.bookstoremanagement.controller;

import java.util.Date;
import java.text.SimpleDateFormat;

import com.hexaware.bookstoremanagement.entity.*;
import com.hexaware.bookstoremanagement.service.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/Books")
public class BookController  {

    final BookService bookService;

    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }


    @PostMapping()
    public void addBook(@RequestBody Book book) {
        bookService.createBook(book);
    }

    @GetMapping()
    public List<Book> getAllBook() {
        Date dNow = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");

        bookService.createBook(new Book(1,"DBMS","author","2021/02/22",20));
        return bookService.getAllBooks();
    }

    @GetMapping("/{id}")
    public int getBook(@PathVariable("id") int id) {
        return bookService.getBook(id);
    }


    @GetMapping("/{id}/name")
    public String getBookName(@PathVariable("id") int id) {
        return bookService.getBookName(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable("id") int id,
                                           @RequestBody Book book) {
        return  bookService.updateBook(id, book);
    }

    @DeleteMapping("/{id}")
    public void removeUser(@PathVariable("id") int id) {
        bookService.deleteBook(id);
    }

}
