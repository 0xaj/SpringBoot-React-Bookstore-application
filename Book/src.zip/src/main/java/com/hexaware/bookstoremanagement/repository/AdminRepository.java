package com.hexaware.bookstoremanagement.repository;

import org.springframework.stereotype.Component;
import com.hexaware.bookstoremanagement.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;



@Component
public interface AdminRepository extends JpaRepository<Admin,Integer> {

}
