--delete from book where book_id = 1;
--delete from cart;
--select * from customer where name = 'test@c.com' and password = '123456'
--insert into  customer values(1,'sa@gg.com','me','me')
----        System.out.println(customerService.getAllCustomers());
show databases;

